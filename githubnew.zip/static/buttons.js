function submit() {
    const dataURI = canvas.toDataURL("image/jpeg");
    document.getElementById("uri").innerHTML = dataURI;
    var latex = latexstring;
    document.getElementById("latex").innerHTML = latex;
    $.ajax({
        type: "POST",
        url: "/process",
        data: {param: dataURI}
    });

}
function restart() {
    document.getElementById("uri").innerHTML = "";
    restartarray();
    redraw();
}